import {
  createContext,
  useCallback,
  useContext,
  useMemo,
  useState,
  type ReactNode,
} from "react";

export type StoredCreds = {
  apiKey: string;
  apiSecret: string;
  connectionName: string;
  /** UI preference — wire to futures position sync later. */
  importOpenPositions: boolean;
};

const STORAGE_KEY = "binance_futures_creds_v1";

function load(): StoredCreds {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      return {
        apiKey: "",
        apiSecret: "",
        connectionName: "My Binance",
        importOpenPositions: true,
      };
    }
    const j = JSON.parse(raw) as Partial<StoredCreds> & { apiKey?: string; apiSecret?: string };
    return {
      apiKey: j.apiKey ?? "",
      apiSecret: j.apiSecret ?? "",
      connectionName: typeof j.connectionName === "string" ? j.connectionName : "My Binance",
      importOpenPositions: j.importOpenPositions !== false,
    };
  } catch {
    return {
      apiKey: "",
      apiSecret: "",
      connectionName: "My Binance",
      importOpenPositions: true,
    };
  }
}

type Ctx = StoredCreds & {
  setApiKey: (v: string) => void;
  setApiSecret: (v: string) => void;
  setConnectionName: (v: string) => void;
  setImportOpenPositions: (v: boolean) => void;
  save: () => void;
  clear: () => void;
};

const CredentialsContext = createContext<Ctx | null>(null);

export function CredentialsProvider({ children }: { children: ReactNode }) {
  const loaded = load();
  const [apiKey, setApiKey] = useState(loaded.apiKey);
  const [apiSecret, setApiSecret] = useState(loaded.apiSecret);
  const [connectionName, setConnectionName] = useState(loaded.connectionName);
  const [importOpenPositions, setImportOpenPositions] = useState(loaded.importOpenPositions);

  const save = useCallback(() => {
    const payload: StoredCreds = {
      apiKey,
      apiSecret,
      connectionName,
      importOpenPositions,
    };
    localStorage.setItem(STORAGE_KEY, JSON.stringify(payload));
  }, [apiKey, apiSecret, connectionName, importOpenPositions]);

  const clear = useCallback(() => {
    setApiKey("");
    setApiSecret("");
    setConnectionName("My Binance");
    setImportOpenPositions(true);
    localStorage.removeItem(STORAGE_KEY);
  }, []);

  const value = useMemo(
    () => ({
      apiKey,
      apiSecret,
      connectionName,
      importOpenPositions,
      setApiKey,
      setApiSecret,
      setConnectionName,
      setImportOpenPositions,
      save,
      clear,
    }),
    [
      apiKey,
      apiSecret,
      connectionName,
      importOpenPositions,
      save,
      clear,
    ]
  );

  return (
    <CredentialsContext.Provider value={value}>{children}</CredentialsContext.Provider>
  );
}

export function useCredentials(): Ctx {
  const v = useContext(CredentialsContext);
  if (!v) throw new Error("CredentialsProvider missing");
  return v;
}
