import { KeyRound, Link2, Trash2 } from "lucide-react";
import { useState } from "react";
import { ConnectBinanceModal } from "@/components/ConnectBinanceModal";
import { useCredentials } from "@/context/CredentialsContext";

export function SettingsPanel() {
  const {
    apiKey,
    apiSecret,
    connectionName,
    setApiKey,
    setApiSecret,
    save,
    clear,
  } = useCredentials();
  const [showConnect, setShowConnect] = useState(false);
  const connected = Boolean(apiKey.trim());

  return (
    <>
      <ConnectBinanceModal open={showConnect} onClose={() => setShowConnect(false)} />
      <div className="mx-auto max-w-xl space-y-6">
        <div className="ui-card p-6 sm:p-8">
          <h2 className="mb-2 flex items-center gap-3 text-lg font-semibold tracking-tight text-white">
            <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-sky-500/25 to-indigo-600/20 ring-1 ring-white/10">
              <KeyRound className="h-5 w-5 text-sky-300" />
            </span>
            Binance Futures
          </h2>
          <p className="mb-6 text-sm leading-relaxed text-zinc-500">
            We never upload your secret to a server in this build — it stays in this browser only. For
            peace of mind create a <span className="text-zinc-300">separate API key</span> with
            futures trading on, withdrawals off, and your home IP (from the footer) whitelisted.
          </p>

          {connected ? (
            <div className="mb-6 flex items-start gap-3 rounded-xl border border-emerald-500/25 bg-emerald-950/25 px-4 py-3 ring-1 ring-emerald-500/10">
              <span className="mt-0.5 h-2 w-2 shrink-0 rounded-full bg-emerald-400 shadow-[0_0_10px_rgb(52_211_153_/_0.6)]" />
              <div>
                <p className="text-sm font-medium text-emerald-100/95">Connected</p>
                <p className="mt-0.5 text-xs text-emerald-200/70">
                  <span className="font-semibold text-white">{connectionName}</span> · key stored
                  locally in this profile
                </p>
              </div>
            </div>
          ) : (
            <div className="mb-6 rounded-xl border border-amber-500/20 bg-amber-950/20 px-4 py-3 text-sm text-amber-200/90 ring-1 ring-amber-500/10">
              No API key on file — open Connect to walk through IP whitelist and paste keys.
            </div>
          )}

          <div className="flex flex-wrap gap-3">
            <button
              type="button"
              onClick={() => setShowConnect(true)}
              className="ui-btn-primary gap-2 px-5 py-2.5"
            >
              <Link2 className="h-4 w-4 opacity-90" />
              {connected ? "Review  connection" : "Connect Binance"}
            </button>
            <button
              type="button"
              onClick={() => setShowConnect(true)}
              className="ui-btn-secondary"
            >
              Update details
            </button>
            <button
              type="button"
              onClick={() => void clear()}
              className="inline-flex items-center gap-2 rounded-xl border border-red-500/30 bg-red-950/25 px-4 py-2.5 text-sm font-medium text-red-300 ring-1 ring-red-500/15 hover:bg-red-950/45"
            >
              <Trash2 className="h-4 w-4" />
              Disconnect
            </button>
          </div>

          <details className="group mt-8 rounded-xl border border-white/[0.08] bg-black/30 open:shadow-inner">
            <summary className="cursor-pointer px-4 py-3 text-xs font-semibold text-zinc-400 transition hover:text-zinc-300 [&::-webkit-details-marker]:hidden">
              Advanced: manual credential fields
            </summary>
            <div className="space-y-4 border-t border-white/[0.06] px-4 pb-4 pt-5">
              <label className="block text-[11px] font-semibold uppercase tracking-wider text-zinc-500">
                API Key
                <input
                  value={apiKey}
                  onChange={(e) => setApiKey(e.target.value)}
                  autoComplete="off"
                  className="ui-input mt-2 w-full font-mono text-sm"
                />
              </label>
              <label className="block text-[11px] font-semibold uppercase tracking-wider text-zinc-500">
                Secret
                <input
                  value={apiSecret}
                  onChange={(e) => setApiSecret(e.target.value)}
                  type="password"
                  autoComplete="off"
                  className="ui-input mt-2 w-full font-mono text-sm"
                  placeholder="••••••••"
                />
              </label>
              <button type="button" onClick={save} className="ui-btn-secondary text-sm">
                Save manual changes
              </button>
            </div>
          </details>
        </div>

        <div className="ui-card px-6 py-5">
          <p className="mb-2 text-xs font-semibold uppercase tracking-wider text-zinc-500">
            IP allowlist reminder
          </p>
          <p className="text-sm leading-relaxed text-zinc-500">
            Restrict your Binance API key by IP and paste addresses from{" "}
            <span className="text-zinc-300">Connect Binance</span> or this page&apos;s footer into{" "}
            <span className="text-zinc-300">API Management → Trusted IPs only</span>.
          </p>
        </div>
      </div>
    </>
  );
}
