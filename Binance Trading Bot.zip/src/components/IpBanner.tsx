import { RefreshCw, Globe } from "lucide-react";
import { usePublicIp } from "@/hooks/usePublicIp";

export function IpBanner() {
  const ip = usePublicIp();

  return (
    <div className="relative z-[1] flex flex-wrap items-center gap-x-4 gap-y-2 border-t border-white/[0.06] bg-[#080a10]/92 px-4 py-2.5 backdrop-blur-lg sm:px-6">
      <div className="flex items-center gap-2 text-xs text-zinc-500">
        <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-white/[0.06] ring-1 ring-white/[0.06]">
          <Globe className="h-3.5 w-3.5 text-zinc-400" />
        </span>
        <span className="hidden font-medium sm:inline">Paste this IP in Binance</span>
        <span className="font-medium sm:hidden">Your IP</span>
      </div>

      <div className="flex flex-wrap items-center gap-2">
        {ip.status === "loading" && (
          <span className="text-xs text-zinc-500">Detecting outbound IP…</span>
        )}
        {ip.status === "error" && (
          <span className="rounded-lg bg-red-950/40 px-2 py-1 text-xs text-red-400 ring-1 ring-red-900/40">
            {ip.message}
          </span>
        )}
        {ip.status === "ok" && (
          <>
            <code className="rounded-lg border border-emerald-500/25 bg-emerald-950/35 px-2.5 py-1 font-mono text-[11px] font-medium tracking-wide text-emerald-400 ring-1 ring-emerald-500/10">
              {ip.ipv4}
            </code>
            <button
              type="button"
              onClick={() => ip.refresh()}
              className="ui-btn-outline gap-1.5 px-2.5 py-1 text-xs font-medium text-zinc-400 hover:text-white"
              title="Refresh detected IP"
            >
              <RefreshCw className="h-3 w-3" />
              Refresh
            </button>
          </>
        )}
      </div>

      <p className="basis-full text-[10px] leading-snug text-zinc-600 sm:basis-auto sm:text-xs sm:text-zinc-600">
        Binance → API Management → your key → &quot;Restrict access&quot; → add addresses like this one.
      </p>
    </div>
  );
}
