import { Bot, Layers, LayoutDashboard, Settings } from "lucide-react";

type Tab = "dashboard" | "bots" | "settings";

export function Sidebar({
  tab,
  onTab,
}: {
  tab: Tab;
  onTab: (t: Tab) => void;
}) {
  const items: { id: Tab; label: string; hint: string; icon: typeof Bot }[] = [
    { id: "dashboard", label: "Home", hint: "Start & learn", icon: LayoutDashboard },
    { id: "bots", label: "Trading bot", hint: "Grid & limits", icon: Bot },
    { id: "settings", label: "Settings", hint: "Binance link", icon: Settings },
  ];

  return (
    <aside className="flex w-[15.5rem] shrink-0 flex-col border-r border-white/[0.07] bg-[#080a10]/90 backdrop-blur-xl">
      <div className="border-b border-white/[0.06] px-5 py-6">
        <div className="mb-4 flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-sky-400/25 to-indigo-500/35 ring-1 ring-sky-400/20">
            <Layers className="h-5 w-5 text-sky-300" strokeWidth={2} />
          </div>
          <div className="min-w-0">
            <div className="truncate text-sm font-semibold tracking-tight text-white">
              Grid TP Pro
            </div>
            <div className="text-[11px] font-medium uppercase tracking-wider text-zinc-500">
              Binance Futures
            </div>
          </div>
        </div>
        <p className="text-xs leading-relaxed text-zinc-500">
          Professional grid take-profit workspace for USDT &amp; USDC perpetuals. Start small and
          validate every step before scaling.
        </p>
      </div>
      <nav className="flex flex-col gap-1 p-3" aria-label="Main">
        {items.map((it) => {
          const Icon = it.icon;
          const active = tab === it.id;
          return (
            <button
              key={it.id}
              type="button"
              onClick={() => onTab(it.id)}
              className={active ? "ui-nav-link ui-nav-link--active" : "ui-nav-link"}
            >
              <span
                className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-lg ${
                  active
                    ? "bg-white/10 text-sky-300"
                    : "bg-white/[0.04] text-zinc-500"
                }`}
              >
                <Icon className="h-4 w-4" strokeWidth={2} />
              </span>
              <span className="flex min-w-0 flex-col items-start">
                <span className="truncate">{it.label}</span>
                {!active && (
                  <span className="text-[10px] font-normal uppercase tracking-wide text-zinc-600">
                    {it.hint}
                  </span>
                )}
              </span>
            </button>
          );
        })}
      </nav>
      <div className="mt-auto border-t border-white/[0.06] p-4">
        <div className="rounded-xl border border-white/[0.06] bg-black/25 px-3 py-3">
          <p className="mb-1 text-[10px] font-semibold uppercase tracking-wider text-zinc-500">
            Connection note
          </p>
          <p className="text-[10px] leading-relaxed text-zinc-600">
            This app talks to Binance through <span className="font-mono text-zinc-500">/binance-fapi</span>{" "}
            during development. In production, keep the same proxy path (or an equivalent backend
            route) so browser requests are permitted.
          </p>
        </div>
      </div>
    </aside>
  );
}
