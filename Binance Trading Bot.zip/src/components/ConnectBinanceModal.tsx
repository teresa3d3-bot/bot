import { ArrowLeft, Check, ChevronDown, Copy, ExternalLink, X } from "lucide-react";
import { useCallback, useEffect, useState } from "react";
import { createPortal } from "react-dom";
import { useCredentials } from "@/context/CredentialsContext";
import { usePublicIp } from "@/hooks/usePublicIp";

const GUIDE_BINANCE_API =
  "https://www.binance.com/en/my/settings/api-management";

type Tab = "fast" | "keys";

export function ConnectBinanceModal({
  open,
  onClose,
}: {
  open: boolean;
  onClose: () => void;
}) {
  const {
    apiKey,
    apiSecret,
    connectionName,
    importOpenPositions,
    setApiKey,
    setApiSecret,
    setConnectionName,
    setImportOpenPositions,
    save,
  } = useCredentials();

  const [tab, setTab] = useState<Tab>("keys");
  const [copiedIp, setCopiedIp] = useState(false);
  const ip = usePublicIp();

  const ipBlockLines =
    ip.status === "ok"
      ? ip.ipv4.split(/\s*,\s*/).concat()
      : ip.status === "error"
        ? [`(could not detect: ${ip.message})`]
        : ["Detecting…"];

  const copyIps = useCallback(async () => {
    const text = ipBlockLines.join("\n");
    try {
      await navigator.clipboard.writeText(text);
      setCopiedIp(true);
      window.setTimeout(() => setCopiedIp(false), 2000);
    } catch {
      /* ignore */
    }
  }, [ipBlockLines]);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  if (!open) return null;

  const modal = (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 sm:p-6">
      <button
        type="button"
        aria-label="Close backdrop"
        className="absolute inset-0 bg-[#05060a]/82 backdrop-blur-md"
        onClick={onClose}
      />
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="connect-binance-title"
        className="relative flex max-h-[min(728px,calc(100vh-1.25rem))] w-full max-w-lg flex-col overflow-hidden rounded-[1.125rem] border border-white/[0.09] bg-gradient-to-b from-[#141821]/98 to-[#0c0e13]/98 shadow-[0_0_80px_-12px_rgb(56_189_248_/_0.25)] backdrop-blur-2xl"
      >
        <header className="flex shrink-0 items-center gap-3 border-b border-white/[0.06] px-4 py-3.5">
          <button
            type="button"
            onClick={onClose}
            className="rounded-xl p-2 text-zinc-400 transition hover:bg-white/[0.06] hover:text-white"
            aria-label="Back"
          >
            <ArrowLeft className="h-5 w-5" />
          </button>
          <h2
            id="connect-binance-title"
            className="flex flex-1 items-center gap-3 text-[1.0625rem] font-semibold tracking-tight text-white"
          >
            <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-[#f0b90b]/18 text-[#f0d38a] ring-1 ring-[#f0b90b]/25">
              <span className="text-[0.9375rem] font-bold leading-none">₿</span>
            </span>
            Connect Binance
          </h2>
          <button
            type="button"
            onClick={onClose}
            className="rounded-xl p-2 text-zinc-400 transition hover:bg-white/[0.06] hover:text-white"
            aria-label="Close"
          >
            <X className="h-5 w-5" />
          </button>
        </header>

        <div className="flex shrink-0 gap-6 border-b border-white/[0.06] px-4">
          {(["fast", "keys"] as const).map((t) => (
            <button
              key={t}
              type="button"
              className={`border-b-[2px] px-2 py-3.5 text-sm font-semibold transition ${
                tab === t
                  ? "border-sky-400 text-white"
                  : "border-transparent text-zinc-500 hover:text-zinc-300"
              }`}
              onClick={() => setTab(t)}
            >
              {t === "fast" ? "Fast Connect" : "API Keys"}
            </button>
          ))}
        </div>

        <div className="flex min-h-0 flex-1 flex-col overflow-y-auto">
          {tab === "fast" ? (
            <div className="space-y-4 p-6 text-sm leading-relaxed text-zinc-400">
              <p>
                OAuth-style provisioning is not used in this self-hosted build. Use{" "}
                <button
                  type="button"
                  className="font-semibold text-sky-400 underline decoration-sky-500/40 underline-offset-2 hover:text-sky-300"
                  onClick={() => setTab("keys")}
                >
                  API Keys
                </button>{" "}
                once your IP whitelist is set.
              </p>
              <button
                type="button"
                onClick={() => setTab("keys")}
                className="ui-btn-primary w-full py-3.5 font-semibold"
              >
                Go to API Keys
              </button>
            </div>
          ) : (
            <>
              <div className="space-y-4 border-b border-white/[0.06] px-6 py-5">
                <div className="flex items-start justify-between gap-3">
                  <h3 className="text-[0.975rem] font-semibold tracking-tight text-white">
                    Connect keys securely
                  </h3>
                  <a
                    href={GUIDE_BINANCE_API}
                    target="_blank"
                    rel="noreferrer noopener"
                    className="inline-flex shrink-0 items-center gap-1.5 rounded-full border border-white/[0.1] bg-white/[0.04] px-2.5 py-1 text-[11px] font-semibold text-sky-300 ring-1 ring-sky-500/15 hover:bg-white/[0.07]"
                  >
                    Full guide
                    <ExternalLink className="h-3 w-3 opacity-70" />
                  </a>
                </div>
                <ol className="list-decimal space-y-3 pl-4 text-[13px] leading-relaxed text-zinc-400">
                  <li>
                    Log in to Binance and open{" "}
                    <span className="text-zinc-200">Wallet → API Management</span>.
                  </li>
                  <li>
                    Enable{" "}
                    <span className="text-zinc-200">&quot;Restrict access to trusted IPs&quot;</span>{" "}
                    — paste outbound addresses your requests use:
                  </li>
                  <div className="relative my-3 ml-[-0.5rem] overflow-hidden rounded-xl border border-emerald-500/20 bg-gradient-to-br from-emerald-950/50 to-black/60 px-3.5 py-3 font-mono text-[13px] leading-relaxed text-emerald-200/95 shadow-inner shadow-black/40 ring-1 ring-emerald-500/15">
                    <div className="whitespace-pre pr-12">{ipBlockLines.join("\n")}</div>
                    <button
                      type="button"
                      title="Copy IPs"
                      onClick={() => void copyIps()}
                      className="absolute right-2 top-2 rounded-lg p-2 text-zinc-500 transition hover:bg-white/[0.08] hover:text-emerald-300"
                    >
                      {copiedIp ? (
                        <Check className="h-4 w-4 text-emerald-400" />
                      ) : (
                        <Copy className="h-4 w-4" />
                      )}
                    </button>
                  </div>
                  <li>
                    Paste the Futures-capable keys below — enable USD‑M Futures, disallow withdrawal.
                  </li>
                </ol>
              </div>

              <div className="space-y-4 px-6 py-5">
                <label className="block text-[11px] font-bold uppercase tracking-[0.12em] text-zinc-500">
                  Name
                  <input
                    value={connectionName}
                    onChange={(e) => setConnectionName(e.target.value)}
                    className="ui-input mt-2 w-full"
                  />
                </label>
                <label className="block text-[11px] font-bold uppercase tracking-[0.12em] text-zinc-500">
                  API Key
                  <input
                    value={apiKey}
                    onChange={(e) => setApiKey(e.target.value)}
                    autoComplete="off"
                    spellCheck={false}
                    className="ui-input mt-2 w-full font-mono text-[13px]"
                  />
                </label>
                <label className="block text-[11px] font-bold uppercase tracking-[0.12em] text-zinc-500">
                  API Secret
                  <input
                    value={apiSecret}
                    onChange={(e) => setApiSecret(e.target.value)}
                    type="password"
                    autoComplete="off"
                    spellCheck={false}
                    className="ui-input mt-2 w-full font-mono text-[13px]"
                  />
                </label>

                <label className="flex cursor-pointer gap-3 rounded-xl border border-white/[0.08] bg-white/[0.03] px-3.5 py-3 ring-1 ring-inset ring-white/[0.04] transition hover:bg-white/[0.05]">
                  <input
                    type="checkbox"
                    checked={importOpenPositions}
                    onChange={(e) => setImportOpenPositions(e.target.checked)}
                    className="mt-0.5 h-4 w-4 shrink-0 rounded border-white/20 bg-black/40 text-sky-500 focus:ring-2 focus:ring-sky-500/30"
                  />
                  <span className="text-sm leading-snug text-zinc-300">
                    Import all open positions when connecting the exchange
                  </span>
                </label>
                <p className="text-[11px] text-zinc-500">
                  Persists locally only — syncing live positions has not shipped yet.
                </p>

                <details className="group rounded-xl border border-white/[0.06] bg-black/30">
                  <summary className="flex cursor-pointer list-none items-center gap-2 px-3.5 py-2.5 text-xs text-zinc-400 [&::-webkit-details-marker]:hidden">
                    <ChevronDown className="h-4 w-4 shrink-0 text-zinc-500 transition-transform group-open:rotate-180" />
                    Account types when issuing keys
                  </summary>
                  <div className="border-t border-white/[0.06] px-3.5 pb-3 pt-2 text-[11px] leading-relaxed text-zinc-500">
                    Turn on <span className="text-zinc-300">USD‑M Futures</span> trading. Omit
                    withdrawal; IP-restrict in all environments.
                  </div>
                </details>

                <button
                  type="button"
                  disabled={!apiKey.trim() || !apiSecret.trim()}
                  onClick={() => {
                    save();
                    onClose();
                  }}
                  className="ui-btn-primary w-full py-3.5 text-[0.9375rem] font-semibold"
                >
                  Connect
                </button>

                <p className="text-center text-[11px] text-zinc-600">
                  New to Binance?{" "}
                  <a
                    href="https://accounts.binance.com/register"
                    target="_blank"
                    rel="noreferrer noopener"
                    className="font-semibold text-sky-400/95 underline decoration-sky-500/30 underline-offset-2 hover:text-sky-300"
                  >
                    Create an account
                  </a>
                </p>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );

  return createPortal(modal, document.body);
}
