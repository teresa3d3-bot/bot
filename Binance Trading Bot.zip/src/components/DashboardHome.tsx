import { ArrowRight, BarChart3, LineChart, Shield } from "lucide-react";

export function DashboardHome() {
  const cards: {
    title: string;
    value: string;
    sub: string;
    icon: typeof LineChart;
    grad: string;
    iconColor: string;
  }[] = [
    {
      title: "Your position",
      value: "One pair at a time",
      sub: "Smaller “safety” orders scale in; your main price line grows one big exit order at the anchor.",
      icon: LineChart,
      grad: "from-sky-500/25 to-sky-700/10",
      iconColor: "text-sky-300",
    },
    {
      title: "Markets",
      value: "USDT & USDC",
      sub: "Search Binance’s list and save favourites. You can add everything with one tap if you want.",
      icon: BarChart3,
      grad: "from-violet-500/25 to-indigo-700/10",
      iconColor: "text-violet-300",
    },
    {
      title: "Safety",
      value: "Keys & IP",
      sub: "Use a read-only style key: futures trading on, withdrawals off, and only your IP allowed.",
      icon: Shield,
      grad: "from-emerald-500/25 to-teal-800/10",
      iconColor: "text-emerald-300",
    },
  ];

  return (
    <div className="space-y-8">
      <div className="rounded-2xl border border-sky-500/20 bg-gradient-to-r from-sky-950/30 to-indigo-950/20 px-4 py-4 ring-1 ring-sky-500/10 sm:px-5 sm:py-5">
        <p className="text-sm font-medium text-white">Welcome</p>
        <p className="mt-1 max-w-3xl text-sm leading-relaxed text-zinc-400">
          This workspace helps you plan <span className="text-zinc-300">step-down (or step-up)</span>{" "}
          limit orders and keep a single take-profit line at your chosen price. Use{" "}
          <span className="font-medium text-zinc-300">practice</span> buttons first; go live only
          when you understand each field.
        </p>
      </div>

      <div className="grid gap-5 sm:grid-cols-3">
        {cards.map((c) => (
          <div
            key={c.title}
            className="ui-card group relative overflow-hidden p-5 transition duration-300 hover:border-white/[0.11]"
          >
            <div className="pointer-events-none absolute inset-0 bg-gradient-to-br from-white/[0.02] to-transparent opacity-0 transition group-hover:opacity-100" />
            <div
              className={`mb-4 inline-flex h-11 w-11 items-center justify-center rounded-xl bg-gradient-to-br ${c.grad} ring-1 ring-white/10`}
            >
              <c.icon className={`h-5 w-5 ${c.iconColor}`} strokeWidth={2} />
            </div>
            <div className="ui-subtle text-[10px] font-bold uppercase tracking-[0.14em]">{c.title}</div>
            <div className="mt-1 text-lg font-semibold tracking-tight text-white">{c.value}</div>
            <p className="mt-2 text-sm leading-relaxed text-zinc-500">{c.sub}</p>
          </div>
        ))}
      </div>

      <div className="ui-card ui-card-accent overflow-hidden p-0 sm:flex">
        <div className="min-w-0 flex-[1.35] p-6 sm:p-8">
          <h2 className="ui-title mb-1 flex items-center gap-2 text-lg">
            Follow these steps
            <ArrowRight className="h-4 w-4 text-sky-400/80" />
          </h2>
          <p className="mb-6 text-sm text-zinc-500">
            Roughly five minutes from zero to a saved plan — you can stay in “paper” mode as long
            as you like.
          </p>
          <ol className="space-y-4 text-sm">
            {[
              "Open Settings → Connect Binance and add the IP from the bottom bar to Binance “trusted IPs”.",
              "Open Trading bot → use the pair list on the left: search e.g. ETH/USDT and tap a row to save it.",
              "Set Anchor to your main price line; Use mark copies today’s futures reference price if you want.",
              "Press Create grid plan. Try Practice on a row to see how the exit line at the anchor grows.",
              "When ready, Send grid to Binance posts your limits (needs API keys and an open position if using reduce-only legs).",
            ].map((step, i) => (
              <li key={i} className="flex gap-3">
                <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-sky-500/30 to-indigo-600/20 text-[11px] font-bold tabular-nums text-sky-200 ring-1 ring-white/10">
                  {i + 1}
                </span>
                <span className="pt-0.5 leading-snug text-zinc-400">{step}</span>
              </li>
            ))}
          </ol>
        </div>
        <div className="relative flex flex-1 flex-col justify-center gap-4 border-t border-white/[0.06] bg-black/20 p-6 sm:border-l sm:border-t-0 sm:p-8">
          <div className="absolute inset-0 bg-gradient-to-bl from-indigo-500/[0.07] via-transparent to-sky-500/[0.05]" />
          <div className="relative rounded-xl border border-white/[0.08] bg-white/[0.03] px-4 py-3 backdrop-blur-sm">
            <p className="text-[10px] font-bold uppercase tracking-wider text-zinc-500">
              Friendly reminders
            </p>
            <ul className="mt-3 space-y-2 text-xs leading-relaxed text-zinc-400">
              <li>• Start with small quote-per-level until the math feels familiar.</li>
              <li>• “Hedge mode” only if your Binance account uses separate long/short sides.</li>
              <li>• API keys in a browser are convenient but risky on shared computers.</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
