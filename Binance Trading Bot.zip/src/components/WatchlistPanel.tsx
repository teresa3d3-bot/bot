import { ListPlus, Trash2 } from "lucide-react";
import { useCallback, useEffect, useMemo, useState } from "react";
import { FieldHint } from "@/components/FieldHint";
import { exchangeInfo, filterUsdMarginSymbols } from "@/lib/binanceFutures";
import { pairLabelToSymbol, symbolToPairLabel } from "@/lib/futuresPairFormat";

const WL_KEY = "futures_watchlist_v1";

function loadWl(): string[] {
  try {
    const raw = localStorage.getItem(WL_KEY);
    if (!raw) return ["BTCUSDT", "ETHUSDT"];
    const j = JSON.parse(raw) as unknown;
    return Array.isArray(j) ? j.filter((x) => typeof x === "string") : ["BTCUSDT"];
  } catch {
    return ["BTCUSDT"];
  }
}

function sortSymbols(a: string, b: string): number {
  return symbolToPairLabel(a).localeCompare(symbolToPairLabel(b), undefined, {
    sensitivity: "base",
  });
}

export function WatchlistPanel({
  activeSymbol,
  onSelect,
}: {
  activeSymbol: string;
  onSelect: (s: string) => void;
}) {
  const [list, setList] = useState<string[]>(() => loadWl().sort(sortSymbols));
  const [allSymbols, setAllSymbols] = useState<string[]>([]);
  const [search, setSearch] = useState("");
  const [loadErr, setLoadErr] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    void (async () => {
      try {
        const info = await exchangeInfo();
        if (cancelled) return;
        setAllSymbols(filterUsdMarginSymbols(info.symbols).sort(sortSymbols));
        setLoadErr(null);
      } catch (e) {
        if (!cancelled)
          setLoadErr(
            e instanceof Error
              ? e.message
              : "Could not load pairs — check internet or your /binance-fapi proxy."
          );
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  const persist = useCallback((next: string[]) => {
    const sorted = [...next].sort(sortSymbols);
    setList(sorted);
    localStorage.setItem(WL_KEY, JSON.stringify(sorted));
  }, []);

  const addSymbol = useCallback(
    (sym: string) => {
      const s = sym.trim().toUpperCase();
      if (!s || list.includes(s)) return;
      persist([...list, s]);
      onSelect(s);
    },
    [list, onSelect, persist]
  );

  const addAllFromBinance = useCallback(() => {
    if (allSymbols.length === 0) return;
    const merged = [...new Set([...list, ...allSymbols])].sort(sortSymbols);
    persist(merged);
    if (!merged.includes(activeSymbol) && merged[0]) onSelect(merged[0]);
  }, [activeSymbol, allSymbols, list, onSelect, persist]);

  const remove = useCallback(
    (s: string) => {
      const next = list.filter((x) => x !== s);
      persist(next);
      if (activeSymbol === s && next[0]) onSelect(next[0]);
    },
    [activeSymbol, list, onSelect, persist]
  );

  const available = useMemo(() => {
    const set = new Set(list);
    return allSymbols
      .filter((sym) => !set.has(sym))
      .map((sym) => ({ symbol: sym, label: symbolToPairLabel(sym) }));
  }, [allSymbols, list]);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return available;
    return available.filter(
      ({ symbol, label }) =>
        label.toLowerCase().includes(q) || symbol.toLowerCase().includes(q)
    );
  }, [available, search]);

  const tryAddFromSearch = useCallback(() => {
    const q = search.trim();
    if (!q) return;
    const parsed = pairLabelToSymbol(q);
    if (parsed && available.some((o) => o.symbol === parsed)) {
      addSymbol(parsed);
      setSearch("");
      return;
    }
    if (filtered.length === 1) {
      addSymbol(filtered[0].symbol);
      setSearch("");
    }
  }, [addSymbol, available, filtered, search]);

  return (
    <div className="ui-card p-5">
      <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
        <div>
          <h2 className="text-[0.95rem] font-semibold tracking-tight text-white">
            Your pairs
          </h2>
          <p className="mt-1 text-[11px] font-medium uppercase tracking-wider text-zinc-600">
            Tap to trade · swipe list to scroll
          </p>
        </div>
        {loadErr && (
          <span className="max-w-[13rem] text-right text-[11px] leading-snug text-amber-400/95" title={loadErr}>
            Can’t load market list. Check connection or dev proxy.
          </span>
        )}
      </div>

      <p className="mb-4 text-xs leading-relaxed text-zinc-500">
        The row with the blue highlight is the pair your grid uses on the right. Remove with the trash
        icon if you tidy up later.
      </p>

      <div className="ui-inset mb-4 overflow-hidden">
        <p className="border-b border-white/[0.05] px-3 py-2 text-[10px] font-semibold uppercase tracking-wider text-zinc-600">
          Saved favourites
        </p>
        <div className="max-h-[11rem] space-y-0.5 overflow-y-auto p-1.5">
          {list.length === 0 ? (
            <p className="px-2 py-6 text-center text-xs text-zinc-600">
              No pairs yet — add from the searchable list below, or use &quot;Add all&quot;.
            </p>
          ) : (
            list.map((s) => (
              <div key={s} className="flex gap-1">
                <button
                  type="button"
                  onClick={() => onSelect(s)}
                  className={`min-w-0 flex-1 truncate rounded-lg px-3 py-2 text-left text-sm font-semibold tracking-tight transition ${
                    s === activeSymbol
                      ? "bg-gradient-to-r from-sky-500/20 to-indigo-600/15 text-white ring-1 ring-sky-400/25"
                      : "text-zinc-400 hover:bg-white/[0.05] hover:text-zinc-200"
                  }`}
                >
                  {symbolToPairLabel(s)}
                  {s === activeSymbol ? (
                    <span className="ml-2 text-[10px] font-normal text-sky-300/90">● active</span>
                  ) : null}
                </button>
                <button
                  type="button"
                  title={`Remove ${symbolToPairLabel(s)} from favourites`}
                  onClick={() => remove(s)}
                  className="rounded-lg p-2 text-zinc-600 transition hover:bg-red-950/35 hover:text-red-400"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            ))
          )}
        </div>
      </div>

      <label className="mb-1 block text-[11px] font-bold uppercase tracking-[0.11em] text-zinc-500">
        Find more pairs on Binance
      </label>
      <input
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        onKeyDown={(e) => {
          if (e.key === "Enter") tryAddFromSearch();
        }}
        placeholder="Type a name… e.g. SOL, BTC, ETH/USDT"
        className="ui-input w-full text-sm placeholder:text-zinc-600"
        aria-describedby="pair-search-hint"
      />
      <FieldHint id="pair-search-hint">
        Matches below update as you type. Press Enter when only one row is visible to add it
        quickly.
      </FieldHint>

      <div className="mb-4 mt-4 max-h-[10.5rem] overflow-y-auto rounded-xl border border-white/[0.07] bg-black/35 shadow-inner shadow-black/40 ring-1 ring-inset ring-white/[0.04]">
        {filtered.length === 0 ? (
          <div className="px-3 py-8 text-center text-xs leading-relaxed text-zinc-600">
            {available.length === 0
              ? "Every tradable perpetual is already in your list above."
              : "Nothing matches — clear the box or spell the symbol differently (e.g. 1000PEPE)."}
          </div>
        ) : (
          <ul className="divide-y divide-white/[0.05]">
            {filtered.map(({ symbol: sym, label }) => (
              <li key={sym}>
                <button
                  type="button"
                  onClick={() => addSymbol(sym)}
                  className="flex w-full items-center px-3 py-2.5 text-left text-sm font-medium text-zinc-300 transition hover:bg-sky-500/[0.08] hover:text-white"
                >
                  <span>Add {label}</span>
                  <span className="ml-auto text-[11px] text-zinc-600">tap</span>
                </button>
              </li>
            ))}
          </ul>
        )}
      </div>

      <button
        type="button"
        onClick={addAllFromBinance}
        disabled={allSymbols.length === 0}
        className="flex w-full flex-col items-center justify-center gap-0.5 rounded-xl border border-violet-500/25 bg-violet-950/25 px-3 py-2.5 text-sm font-semibold text-violet-200/95 ring-1 ring-violet-500/15 transition hover:bg-violet-950/40 disabled:opacity-35"
      >
        <span className="flex items-center gap-2">
          <ListPlus className="h-4 w-4" />
          Add every USDT &amp; USDC pair
        </span>
        <span className="text-[11px] font-normal text-violet-300/75">
          {allSymbols.length} markets — fine for scrolling, heavier for the sidebar
        </span>
      </button>
    </div>
  );
}
