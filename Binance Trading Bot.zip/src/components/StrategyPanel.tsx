import { Activity, Info, RotateCcw, Sparkles, Zap } from "lucide-react";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { FieldHint } from "@/components/FieldHint";
import { useCredentials } from "@/context/CredentialsContext";
import {
  exchangeInfo,
  fetchMarkPrice,
  futuresAccount,
  newOrder,
} from "@/lib/binanceFutures";
import { symbolToPairLabel } from "@/lib/futuresPairFormat";
import { lotPriceForSymbol, roundToStep, type SymbolRow } from "@/lib/symbolFilters";
import { cancelOpenLimitsAtPrice, placePlannedGrid } from "@/lib/gridTpExchange";
import {
  applyAnchorTpFill,
  applyDcaFill,
  buildInitialState,
  computeLadderPrices,
  plannedLimitOrders,
  type GridSide,
  type StrategyState,
} from "@/lib/strategyEngine";

const HEDGE_KEY = "futures_hedge_mode_v1";

function loadHedge(): boolean {
  try {
    return localStorage.getItem(HEDGE_KEY) === "1";
  } catch {
    return false;
  }
}

export function StrategyPanel({ symbol }: { symbol: string }) {
  const { apiKey, apiSecret } = useCredentials();
  const [gridSide, setGridSide] = useState<GridSide>("SHORT");
  const [anchor, setAnchor] = useState("");
  const [markRaw, setMarkRaw] = useState<string | null>(null);
  const [markLoading, setMarkLoading] = useState(false);
  const [markErr, setMarkErr] = useState<string | null>(null);
  const [levels, setLevels] = useState(8);
  const [stepPct, setStepPct] = useState(0.6);
  const [quotePerLevel, setQuotePerLevel] = useState(10);
  const [state, setState] = useState<StrategyState | null>(null);
  const [acctMsg, setAcctMsg] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [symbolRows, setSymbolRows] = useState<SymbolRow[]>([]);
  const [hedgeMode, setHedgeMode] = useState(loadHedge);

  useEffect(() => {
    try {
      localStorage.setItem(HEDGE_KEY, hedgeMode ? "1" : "0");
    } catch {
      /* ignore */
    }
  }, [hedgeMode]);

  useEffect(() => {
    let c = false;
    void (async () => {
      try {
        const info = await exchangeInfo();
        if (c) return;
        setSymbolRows(info.symbols as unknown as SymbolRow[]);
      } catch {
        /* ignore */
      }
    })();
    return () => {
      c = true;
    };
  }, []);

  const filters = useMemo(
    () => lotPriceForSymbol(symbolRows, symbol) ?? { tickSize: 0.0001, stepSize: 0.001 },
    [symbolRows, symbol]
  );

  /** Last symbol we applied anchor from mark for (updated only after fetch succeeds). */
  const anchorSyncedForSymbolRef = useRef<string | null>(null);
  const markCacheRef = useRef<Record<string, string>>({});

  const anchorVsMarkPct = useMemo(() => {
    const a = Number(anchor);
    const m = markRaw !== null ? Number(markRaw) : NaN;
    if (!Number.isFinite(a) || a <= 0 || !Number.isFinite(m) || m <= 0) return null;
    return Math.abs(a - m) / m;
  }, [anchor, markRaw]);

  useEffect(() => {
    const symChanged = anchorSyncedForSymbolRef.current !== symbol;
    const cached = markCacheRef.current[symbol];
    let cancelled = false;
    if (cached) {
      setMarkRaw(cached);
    }
    if (symChanged && !cached) {
      setMarkLoading(true);
      setMarkErr(null);
    }
    void (async () => {
      try {
        const raw = await fetchMarkPrice(symbol);
        if (cancelled) return;
        markCacheRef.current[symbol] = raw;
        setMarkRaw(raw);
        if (symChanged) {
          setAnchor(roundToStep(Number(raw), filters.tickSize, "round"));
          anchorSyncedForSymbolRef.current = symbol;
          setMarkErr(null);
        }
      } catch (e) {
        if (!cancelled && symChanged) {
          setMarkErr(e instanceof Error ? e.message : "Mark price failed");
          setMarkRaw(null);
        }
      } finally {
        if (!cancelled && symChanged && !cached) setMarkLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [filters.tickSize, symbol]);

  useEffect(() => {
    const id = window.setInterval(() => {
      void (async () => {
        try {
          const raw = await fetchMarkPrice(symbol);
          setMarkRaw(raw);
        } catch {
          /* keep previous mark */
        }
      })();
    }, 15_000);
    return () => window.clearInterval(id);
  }, [symbol]);

  const snapAnchorToMark = useCallback(() => {
    if (!markRaw) return;
    setAnchor(roundToStep(Number(markRaw), filters.tickSize, "round"));
  }, [filters.tickSize, markRaw]);

  const previewPrices = useMemo(() => {
    const a = Number(anchor);
    if (!Number.isFinite(a) || a <= 0) return [];
    return computeLadderPrices(a, gridSide, Math.min(20, Math.max(1, levels)), stepPct);
  }, [anchor, gridSide, levels, stepPct]);

  const init = useCallback(() => {
    const a = Number(anchor);
    if (!Number.isFinite(a) || a <= 0) return;
    setState(
      buildInitialState({
        symbol,
        gridSide,
        anchorPrice: a,
        levelCount: Math.min(20, Math.max(1, Math.floor(levels))),
        stepPct,
        quotePerLevel,
      })
    );
  }, [anchor, gridSide, levels, quotePerLevel, stepPct, symbol]);

  const testConnection = useCallback(async () => {
    setAcctMsg(null);
    if (!apiKey || !apiSecret) {
      setAcctMsg("Add API key and secret in Settings.");
      return;
    }
    setBusy(true);
    try {
      const acc = await futuresAccount(apiKey, apiSecret);
      const usdt = acc.assets?.find((x) => x.asset === "USDT");
      const usdc = acc.assets?.find((x) => x.asset === "USDC");
      const parts = [usdt && `USDT avail ${usdt.availableBalance}`, usdc && `USDC avail ${usdc.availableBalance}`].filter(
        Boolean
      );
      setAcctMsg(parts.length ? parts.join(" · ") : "Connected (no USDT/USDC row parsed).");
    } catch (e) {
      setAcctMsg(e instanceof Error ? e.message : "Account request failed");
    } finally {
      setBusy(false);
    }
  }, [apiKey, apiSecret]);

  const placeConsolidatedOnly = useCallback(async () => {
    setAcctMsg(null);
    if (!state?.consolidated || !apiKey || !apiSecret) {
      setAcctMsg("Initialize strategy and ensure API keys are set.");
      return;
    }
    const c = state.consolidated;
    const qty = roundToStep(c.baseQty, filters.stepSize, "floor");
    const price = roundToStep(c.price, filters.tickSize, "floor");
    if (Number(qty) <= 0) {
      setAcctMsg("Consolidated qty rounds to zero — increase quote per level.");
      return;
    }
    setBusy(true);
    try {
      const n = await cancelOpenLimitsAtPrice(
        apiKey,
        apiSecret,
        symbol,
        state.anchorPrice,
        filters.tickSize,
        c.side
      );
      await newOrder({
        apiKey,
        apiSecret,
        symbol,
        side: c.side,
        type: "LIMIT",
        quantity: qty,
        price,
        positionSide: hedgeMode ? gridSide : undefined,
        timeInForce: "GTC",
        reduceOnly: false,
      });
      setAcctMsg(
        `Placed ${c.side} LIMIT ${qty} @ ${price} (${gridSide}).` +
          (n > 0 ? ` Replaced ${n} prior anchor order(s).` : "")
      );
    } catch (e) {
      setAcctMsg(e instanceof Error ? e.message : "Order failed");
    } finally {
      setBusy(false);
    }
  }, [apiKey, apiSecret, filters, gridSide, state, symbol]);

  const placeOneDcaLeg = useCallback(
    async (levelIndex: number) => {
      setAcctMsg(null);
      if (!state || !apiKey || !apiSecret) return;
      const leg = state.ladder.find((l) => l.levelIndex === levelIndex);
      if (!leg || leg.filled) return;
      const dcaSide: "BUY" | "SELL" = gridSide === "SHORT" ? "BUY" : "SELL";
      const qty = roundToStep(leg.baseQty, filters.stepSize, "floor");
      const price = roundToStep(leg.price, filters.tickSize, "floor");
      if (Number(qty) <= 0) {
        const minQuote = leg.price * filters.stepSize;
        setAcctMsg(
          `This order is too small for Binance step size on ${symbol}. Raise size per step above ~${minQuote.toFixed(4)} quote.`
        );
        return;
      }
      setBusy(true);
      try {
        await newOrder({
          apiKey,
          apiSecret,
          symbol,
          side: dcaSide,
          type: "LIMIT",
          quantity: qty,
          price,
          positionSide: hedgeMode ? gridSide : undefined,
          timeInForce: "GTC",
          reduceOnly: true,
        });
        setAcctMsg(
          `Placed DCA ${dcaSide} L${levelIndex} ${qty} @ ${price}. It stays open until Binance fills it.`
        );
      } catch (e) {
        setAcctMsg(e instanceof Error ? e.message : "Order failed");
      } finally {
        setBusy(false);
      }
    },
    [apiKey, apiSecret, filters, gridSide, state]
  );

  const deployFullGrid = useCallback(async () => {
    setAcctMsg(null);
    if (!state || !apiKey || !apiSecret) {
      setAcctMsg("Create a grid plan first (blue button above), then try sending to Binance.");
      return;
    }
    if (state.symbol !== symbol) {
      setAcctMsg("You changed the pair — press Create grid plan again for the new symbol.");
      return;
    }
    const anchorPx = state.anchorPrice;
    const plans = plannedLimitOrders(state);
    if (plans.length === 0) {
      setAcctMsg("No open legs — all DCA levels filled or zero consolidated size.");
      return;
    }
    const tinyPlan = plans.find((p) => Number(roundToStep(p.baseQty, filters.stepSize, "floor")) <= 0);
    if (tinyPlan) {
      const minQuote = tinyPlan.price * filters.stepSize;
      const kind = tinyPlan.role === "dca" ? `DCA level ${tinyPlan.levelIndex}` : "anchor order";
      setAcctMsg(
        `${kind} is too small after Binance quantity rounding. Increase size per step (try above ~${minQuote.toFixed(4)} quote).`
      );
      return;
    }
    setBusy(true);
    try {
      const r = await placePlannedGrid(
        apiKey,
        apiSecret,
        symbol,
        hedgeMode,
        gridSide,
        plans,
        filters,
        anchorPx
      );
      setAcctMsg(
        `Deployed ${r.placed} limit order(s). Canceled ${r.canceledAtAnchor} prior anchor order(s) on that side.`
      );
    } catch (e) {
      setAcctMsg(e instanceof Error ? e.message : "Deploy failed");
    } finally {
      setBusy(false);
    }
  }, [apiKey, apiSecret, filters, gridSide, hedgeMode, state, symbol]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-3 rounded-2xl border border-white/[0.08] bg-gradient-to-r from-indigo-950/40 to-sky-950/30 px-4 py-4 ring-1 ring-white/[0.05] sm:flex-row sm:items-start sm:gap-4 sm:px-5">
        <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-white/[0.06] ring-1 ring-white/10">
          <Sparkles className="h-5 w-5 text-amber-200/90" strokeWidth={2} />
        </span>
        <div>
          <p className="text-sm font-semibold text-white">Quick guide</p>
          <ol className="mt-2 list-decimal space-y-1.5 pl-4 text-xs leading-relaxed text-zinc-400">
            <li>Fill the numbers that match how you trade (anchor = your main price line).</li>
            <li>
              Press <span className="font-medium text-zinc-300">Create grid plan</span> to prepare
              the table.
            </li>
            <li>
              Use <span className="font-medium text-zinc-300">Practice</span> to learn without
              sending orders; use Binance buttons only when you mean it.
            </li>
          </ol>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <div className="ui-card p-5 sm:p-6">
          <h2 className="mb-5 flex items-center gap-2.5 text-[0.95rem] font-semibold tracking-tight text-white">
            <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-sky-500/15 ring-1 ring-sky-400/25">
              <Activity className="h-4 w-4 text-sky-400" strokeWidth={2} />
            </span>
            Grid setup
          </h2>
          <div className="grid grid-cols-2 gap-x-4 gap-y-4 text-sm">
            <label className="col-span-2">
              <span className="text-[11px] font-bold uppercase tracking-[0.1em] text-zinc-500">
                Active pair
              </span>
              <div className="mt-2 rounded-xl border border-white/[0.08] bg-black/35 px-3 py-3 ring-1 ring-inset ring-white/[0.04]">
                <div className="text-lg font-semibold tracking-tight text-white">
                  {symbolToPairLabel(symbol)}
                </div>
                <div className="font-mono text-[11px] text-zinc-500">{symbol}</div>
              </div>
              <FieldHint>Change it from the list on the left anytime.</FieldHint>
            </label>
            <label className="text-[11px] font-bold uppercase tracking-[0.1em] text-zinc-500">
              Direction
              <select
                value={gridSide}
                onChange={(e) => setGridSide(e.target.value as GridSide)}
                className="ui-select mt-2 w-full"
                title="Short = expect lower prices first. Long = expect higher prices first."
              >
                <option value="SHORT">Short — add buy limits below the anchor</option>
                <option value="LONG">Long — add sell limits above the anchor</option>
              </select>
              <FieldHint>Pick the side that matches your open futures position on Binance.</FieldHint>
            </label>
            <label className="text-[11px] font-bold uppercase tracking-[0.1em] text-zinc-500">
              Anchor (main price line)
              <div className="mt-2 flex gap-2">
                <input
                  value={anchor}
                  onChange={(e) => setAnchor(e.target.value)}
                  inputMode="decimal"
                  className="ui-input min-w-0 flex-1 font-mono text-[13px]"
                />
                <button
                  type="button"
                  disabled={!markRaw}
                  onClick={snapAnchorToMark}
                  className="ui-btn-outline shrink-0 px-3 py-2 text-xs font-semibold text-sky-400 hover:border-sky-500/35 hover:bg-sky-500/10 hover:text-sky-200 disabled:opacity-40"
                  title="Copy today’s Binance mark price into the box (rounded to allowed ticks)"
                >
                  Copy mark
                </button>
              </div>
              <FieldHint>
                This is the price where your single “exit at entry” order lives. It should match how
                you think about the trade.
              </FieldHint>
              <div className="mt-2 flex flex-wrap items-center gap-x-2 gap-y-0.5 text-[11px] text-zinc-500">
                {markLoading && <span>Loading mark…</span>}
                {!markLoading && markErr && <span className="text-red-400">{markErr}</span>}
                {!markLoading && !markErr && markRaw && (
                  <>
                    <span>
                      Live mark: <span className="font-mono text-zinc-300">{markRaw}</span>
                    </span>
                    <button
                      type="button"
                      onClick={() => {
                        setMarkLoading(true);
                        void (async () => {
                          try {
                            const raw = await fetchMarkPrice(symbol);
                            setMarkRaw(raw);
                            setMarkErr(null);
                          } catch (e) {
                            setMarkErr(e instanceof Error ? e.message : "Refresh failed");
                          } finally {
                            setMarkLoading(false);
                          }
                        })();
                      }}
                      className="font-medium text-sky-400 underline decoration-sky-500/30 underline-offset-2 hover:text-sky-300"
                    >
                      Refresh
                    </button>
                  </>
                )}
              </div>
              {anchorVsMarkPct !== null && anchorVsMarkPct > 0.02 && (
                <p className="mt-1 text-[11px] text-amber-500/90">
                  Your anchor is {(anchorVsMarkPct * 100).toFixed(1)}% away from the live mark —{" "}
                  <button
                    type="button"
                    className="font-medium text-amber-400 underline hover:text-amber-300"
                    onClick={snapAnchorToMark}
                  >
                    Copy mark
                  </button>{" "}
                  if you meant to line up with the market.
                </p>
              )}
            </label>
            <label className="text-[11px] font-bold uppercase tracking-[0.1em] text-zinc-500">
              How many steps? (1–20)
              <input
                type="number"
                min={1}
                max={20}
                value={levels}
                onChange={(e) => setLevels(Number(e.target.value))}
                className="ui-input mt-2 w-full tabular-nums"
              />
              <FieldHint>Each step is one extra limit order further from the anchor.</FieldHint>
            </label>
            <label className="text-[11px] font-bold uppercase tracking-[0.1em] text-zinc-500">
              Space between steps (%)
              <input
                type="number"
                step="0.01"
                value={stepPct}
                onChange={(e) => setStepPct(Number(e.target.value))}
                className="ui-input mt-2 w-full tabular-nums"
              />
              <FieldHint>
                Example: 0.6 means each rung is ~0.6% deeper (short) or higher (long) than the one
                before.
              </FieldHint>
            </label>
            <label className="col-span-2 text-[11px] font-bold uppercase tracking-[0.1em] text-zinc-500">
              Size per step (USDT or USDC notional)
              <input
                type="number"
                min={1}
                value={quotePerLevel}
                onChange={(e) => setQuotePerLevel(Number(e.target.value))}
                className="ui-input mt-2 w-full tabular-nums"
              />
              <FieldHint>
                Rough dollars per ladder rung. Smaller = gentler; larger = faster position changes.
              </FieldHint>
            </label>
            <label className="col-span-2 flex cursor-pointer items-start gap-3 rounded-xl border border-white/[0.08] bg-white/[0.02] px-3 py-3 text-zinc-400 ring-1 ring-inset ring-white/[0.04]">
              <input
                type="checkbox"
                checked={hedgeMode}
                onChange={(e) => setHedgeMode(e.target.checked)}
                className="mt-0.5 h-4 w-4 shrink-0 rounded border-white/25 bg-black/40 text-sky-500 focus:ring-2 focus:ring-sky-500/30"
              />
              <span className="text-xs leading-relaxed">
                <span className="font-medium text-zinc-300">Hedge mode</span> — tell Binance
                whether each order belongs to your long or short side.{" "}
                <span className="text-zinc-500">Turn off if you use the simpler one-way position mode.</span>
              </span>
            </label>
          </div>
          <div className="mt-6 flex flex-wrap gap-3">
            <button type="button" onClick={init} className="ui-btn-primary gap-2 px-5">
              <Zap className="h-4 w-4 opacity-95" strokeWidth={2} />
              Create grid plan
            </button>
            <button
              type="button"
              onClick={() => setState(null)}
              className="ui-btn-secondary gap-2"
              title="Clear the plan from this screen (does not cancel exchange orders)"
            >
              <RotateCcw className="h-4 w-4" strokeWidth={2} />
              Clear plan
            </button>
            {state && (
              <button
                type="button"
                disabled={busy || !apiKey}
                onClick={() => void deployFullGrid()}
                className="inline-flex items-center gap-2 rounded-xl border border-sky-500/35 bg-sky-500/10 px-4 py-2.5 text-sm font-semibold text-sky-200 shadow-[inset_0_1px_0_rgb(255_255_255_/_0.06)] transition hover:bg-sky-500/18 disabled:opacity-40"
                title="Requires API keys in Settings and margin on Binance"
              >
                Send grid to Binance
              </button>
            )}
          </div>
          {state && (
            <p className="mt-4 rounded-lg border border-white/[0.06] bg-black/25 px-3 py-2 text-[11px] leading-relaxed text-zinc-500 ring-1 ring-inset ring-white/[0.04]">
              Live tip: small “scale-in” orders are sent with{" "}
              <span className="font-mono text-zinc-400">reduce only</span> — you need a real{" "}
              {gridSide} position first. The big order at your anchor is normal (not reduce-only) so
              it can rebuild size. One network request per row.
            </p>
          )}
        </div>

        <div className="ui-card ui-card-accent flex flex-col p-5 sm:p-6">
          <h2 className="mb-4 flex items-center gap-2.5 pl-1 text-[0.95rem] font-semibold tracking-tight text-white">
            <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-white/[0.06] ring-1 ring-white/10">
              <Info className="h-4 w-4 text-zinc-300" strokeWidth={2} />
            </span>
            How the anchor exit works
          </h2>
          <div className="flex flex-1 flex-col gap-3 pl-1 text-xs leading-relaxed text-zinc-400">
            <p>
              Your <span className="font-medium text-zinc-200">anchor</span> is the price line where
              this tool keeps <span className="font-medium text-zinc-200">one combined limit order</span>
              . When a smaller ladder order fills, its size is merged into that single order so you
              follow one clear exit instead of many tiny ones.
            </p>
            <p>
              In the <span className="font-medium text-zinc-200">simulator</span>, use{" "}
              <span className="font-medium text-zinc-200">Practice: TP done</span> when you want to
              treat that exit as finished and start a fresh ladder — your cycle counters below keep a
              helpful record. On Binance, use{" "}
              <span className="font-medium text-zinc-200">Update TP order on Binance</span> whenever
              the real order should match a new size.
            </p>
            <p className="text-[11px] text-zinc-500">
              There is no rush: align the plan with your position and risk before sending live orders.
            </p>
          </div>
          <div className="mt-5 rounded-xl border border-white/[0.07] bg-black/40 px-3 py-2.5 ring-1 ring-inset ring-white/[0.04]">
            <p className="text-[10px] font-semibold uppercase tracking-wider text-zinc-500">
              Exchange precision
            </p>
            <p className="mt-1 font-mono text-[11px] tabular-nums text-zinc-400">
              Price tick {filters.tickSize} · quantity step {filters.stepSize}
            </p>
          </div>
        </div>
      </div>

      {previewPrices.length > 0 && !state && (
        <div className="rounded-2xl border border-dashed border-sky-500/25 bg-sky-950/[0.15] px-4 py-3.5 text-xs text-zinc-500 ring-1 ring-sky-500/10">
          <span className="font-semibold uppercase tracking-wide text-sky-500/80">
            Sneak peek of limit prices
          </span>
          <FieldHint>Numbers update as you change anchor, spacing, or direction.</FieldHint>
          <span className="mt-2 block font-mono text-[11px] text-zinc-300">
            {previewPrices.slice(0, 6).join(" → ")}
            {previewPrices.length > 6 ? " …" : ""}
          </span>
        </div>
      )}

      {state && (
        <div className="grid gap-6 xl:grid-cols-3">
          <div className="ui-card p-5 xl:col-span-2">
            <div className="mb-4 flex flex-wrap items-center justify-between gap-2 border-b border-white/[0.06] pb-3">
              <h3 className="text-[0.95rem] font-semibold tracking-tight text-white">
                Your ladder
              </h3>
              <span className="rounded-full border border-white/[0.08] bg-black/35 px-2.5 py-1 text-[10px] font-medium tabular-nums text-zinc-400">
                Cycles {state.cycleCount} · Accum. base {state.accumulatedBaseVolume.toFixed(6)} ·
                Accum. quote ~{state.accumulatedQuoteNotional.toFixed(2)}
              </span>
            </div>
            <div className="overflow-x-auto rounded-xl border border-white/[0.06] bg-black/30 ring-1 ring-inset ring-white/[0.04]">
              <table className="w-full min-w-[520px] text-left text-xs">
                <thead className="bg-white/[0.03] font-semibold uppercase tracking-wider text-zinc-500">
                  <tr>
                    <th className="pb-3 pl-3 pr-2 pt-3">Lv</th>
                    <th className="pb-3 pr-2 pt-3">Limit $</th>
                    <th className="pb-3 pr-2 pt-3">$ size</th>
                    <th className="pb-3 pr-2 pt-3">Coins</th>
                    <th className="pb-3 pr-2 pt-3">Done?</th>
                    <th className="pb-3 pr-3 pt-3">Try it</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/[0.05] font-mono text-[11px] text-zinc-300">
                  {state.ladder.map((leg) => (
                    <tr key={leg.levelIndex} className="bg-transparent hover:bg-white/[0.03]">
                      <td className="py-2.5 pl-3 pr-2 font-semibold text-zinc-400">
                        {leg.levelIndex}
                      </td>
                      <td className="py-2.5 pr-2">{leg.price.toFixed(6)}</td>
                      <td className="py-2.5 pr-2">{leg.quoteNotional}</td>
                      <td className="py-2.5 pr-2">{leg.baseQty.toFixed(6)}</td>
                      <td className="py-2.5 pr-2">
                        {leg.filled ? (
                          <span className="rounded-full bg-emerald-950/55 px-1.5 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-emerald-400">
                            Done
                          </span>
                        ) : (
                          <span className="text-zinc-600">—</span>
                        )}
                      </td>
                      <td className="py-2.5 pr-3">
                        <div className="flex flex-wrap gap-1">
                          <button
                            type="button"
                            disabled={leg.filled}
                            onClick={() => setState((s) => (s ? applyDcaFill(s, leg.levelIndex) : s))}
                            className="ui-btn-outline px-2 py-1 text-[10px] font-semibold"
                            title="Pretend this row filled — no order sent"
                          >
                            Practice
                          </button>
                          <button
                            type="button"
                            disabled={leg.filled || busy || !apiKey}
                            onClick={() => void placeOneDcaLeg(leg.levelIndex)}
                            className="rounded-lg bg-sky-500/15 px-2 py-1 text-[10px] font-semibold text-sky-300 ring-1 ring-sky-500/25 hover:bg-sky-500/25 disabled:opacity-35"
                            title="Send this single limit order to Binance (placing is not the same as filled)"
                          >
                            Send limit
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="ui-card ui-card-accent flex flex-col gap-4 p-5">
            <h3 className="pl-1 text-[0.95rem] font-semibold tracking-tight text-white">
              Exit at your anchor
            </h3>
            {state.consolidated ? (
              <div className="rounded-xl border border-white/[0.08] bg-black/45 p-4 font-mono text-xs text-zinc-300 ring-1 ring-inset ring-white/[0.04]">
                <div>
                  {state.consolidated.side}{" "}
                  <span className="font-semibold text-emerald-400">
                    {state.consolidated.baseQty.toFixed(6)}
                  </span>{" "}
                  @ {state.consolidated.price}
                </div>
                <div className="mt-3 flex flex-col gap-2.5">
                  <button
                    type="button"
                    disabled={busy || !apiKey}
                    onClick={() => void placeConsolidatedOnly()}
                    className="ui-btn-primary w-full justify-center py-2.5 text-sm"
                    title="Cancels the old anchor order on this side first, then places the new size"
                  >
                    Update TP order on Binance
                  </button>
                  <button
                    type="button"
                    onClick={() => setState((s) => (s ? applyAnchorTpFill(s) : s))}
                    className="ui-btn-secondary w-full justify-center py-2.5 text-sm"
                    title="Practice only — pretend the anchored order finished and reset rows"
                  >
                    Practice: TP done
                  </button>
                </div>
              </div>
            ) : (
              <p className="pl-1 text-xs text-zinc-500">
                Practice a ladder row first (or Send limit) — this box appears once there is size to
                park at your anchor price.
              </p>
            )}
            {acctMsg && (
              <p className="rounded-xl border border-white/[0.07] bg-violet-950/20 px-3 py-2.5 text-xs leading-relaxed text-violet-200/90 ring-1 ring-violet-500/20">
                {acctMsg}
              </p>
            )}
            <button
              type="button"
              disabled={busy || !apiKey}
              onClick={() => void testConnection()}
              className="ui-btn-outline w-full justify-center py-2.5 text-sm font-medium disabled:opacity-40"
              title="Lightweight check that your keys work"
            >
              Check connection to Binance
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
