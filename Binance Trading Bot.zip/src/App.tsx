import { useState } from "react";
import { Navigate, Route, Routes, useLocation, useNavigate } from "react-router-dom";
import { CredentialsProvider } from "@/context/CredentialsContext";
import { DashboardHome } from "@/components/DashboardHome";
import { IpBanner } from "@/components/IpBanner";
import { SettingsPanel } from "@/components/SettingsPanel";
import { Sidebar } from "@/components/Sidebar";
import { StrategyPanel } from "@/components/StrategyPanel";
import { WatchlistPanel } from "@/components/WatchlistPanel";

type Tab = "dashboard" | "bots" | "settings";

function Shell() {
  const location = useLocation();
  const navigate = useNavigate();
  const [symbol, setSymbol] = useState("BTCUSDT");
  const path = location.pathname.toLowerCase();
  const tab: Tab = path === "/bot" ? "bots" : path === "/settings" ? "settings" : "dashboard";

  const handleTab = (next: Tab) => {
    if (next === "bots") {
      navigate("/bot");
      return;
    }
    if (next === "settings") {
      navigate("/settings");
      return;
    }
    navigate("/");
  };

  return (
    <div className="ui-shell flex h-full min-h-0 flex-col">
      <div className="flex min-h-0 flex-1">
        <Sidebar tab={tab} onTab={handleTab} />
        <main className="min-w-0 flex-1 overflow-auto">
          <header className="sticky top-0 z-10 border-b border-white/[0.07] bg-[#06070c]/82 px-6 py-5 backdrop-blur-xl sm:px-8">
            <div className="pointer-events-none absolute inset-x-0 bottom-0 h-px bg-gradient-to-r from-transparent via-sky-400/25 to-transparent" />
            <div className="flex flex-wrap items-end justify-between gap-3">
              <div>
                <div className="mb-3 flex flex-wrap items-center gap-2">
                  <span className="ui-chip inline-flex">Futures · USD‑M</span>
                  {tab === "bots" && (
                    <span className="rounded-full border border-sky-500/25 bg-sky-500/10 px-2.5 py-1 text-[10px] font-semibold tracking-wide text-sky-200">
                      Active pair: {symbol}
                    </span>
                  )}
                </div>
                <h1 className="text-xl font-semibold tracking-tight text-white sm:text-2xl">
                  {tab === "dashboard" && "Home"}
                  {tab === "bots" && "Take-Profit Grid Bot"}
                  {tab === "settings" && "Settings"}
                </h1>
                <p className="mt-1 max-w-2xl text-sm text-zinc-500">
                  {tab === "dashboard" &&
                    "Welcome back. Follow the guided checklist below, then open the trading bot when ready."}
                  {tab === "bots" &&
                    "Choose a pair, set your anchor, and create a clean level plan. Practice first, then send live orders with confidence."}
                  {tab === "settings" &&
                    "Connect Binance securely. Your credentials stay stored only in this browser profile."}
                </p>
              </div>
            </div>
          </header>
          <div className="p-6 pb-10 sm:p-8">
            <Routes>
              <Route path="/" element={<DashboardHome />} />
              <Route
                path="/bot"
                element={
                  <div className="flex flex-col gap-8 xl:flex-row xl:items-start">
                    <div className="w-full shrink-0 xl:sticky xl:top-28 xl:max-h-[calc(100vh-8rem)] xl:w-80 xl:overflow-y-auto xl:pr-1">
                      <p className="mb-3 text-xs leading-relaxed text-zinc-500 xl:hidden">
                        <span className="font-medium text-zinc-400">Step 1 —</span> choose which pair
                        you want to trade.
                      </p>
                      <WatchlistPanel activeSymbol={symbol} onSelect={setSymbol} />
                    </div>
                    <div className="min-w-0 flex-1 xl:pt-0">
                      <p className="mb-4 hidden text-xs leading-relaxed text-zinc-500 xl:block">
                        <span className="font-medium text-zinc-400">Step 2 —</span> configure the grid
                        for <span className="text-zinc-300">{symbol}</span>. The list on the left is
                        scrollable when you need more pairs.
                      </p>
                      <StrategyPanel symbol={symbol} />
                    </div>
                  </div>
                }
              />
              <Route path="/settings" element={<SettingsPanel />} />
              <Route path="*" element={<Navigate to="/" replace />} />
            </Routes>
          </div>
        </main>
      </div>
      <IpBanner />
    </div>
  );
}

export default function App() {
  return (
    <CredentialsProvider>
      <Shell />
    </CredentialsProvider>
  );
}
