import { hmacSha256Hex } from "./hmac";

const DEFAULT_BASE = "/binance-fapi";

function baseUrl(): string {
  const b = import.meta.env.VITE_BINANCE_BASE as string | undefined;
  return (b && b.length > 0 ? b : DEFAULT_BASE).replace(/\/$/, "");
}

function toQuery(params: Record<string, string | number | boolean | undefined>): string {
  const parts: string[] = [];
  for (const [k, v] of Object.entries(params)) {
    if (v === undefined) continue;
    parts.push(`${encodeURIComponent(k)}=${encodeURIComponent(String(v))}`);
  }
  return parts.join("&");
}

async function signedFetch(
  method: "GET" | "POST" | "DELETE",
  path: string,
  apiKey: string,
  apiSecret: string,
  params: Record<string, string | number | boolean | undefined> = {}
): Promise<unknown> {
  const timestamp = Date.now();
  const q = toQuery({ ...params, recvWindow: 5000, timestamp });
  const signature = await hmacSha256Hex(apiSecret, q);
  const url = `${baseUrl()}${path}?${q}&signature=${signature}`;
  const res = await fetch(url, {
    method,
    headers: { "X-MBX-APIKEY": apiKey },
  });
  const text = await res.text();
  let data: unknown = text;
  try {
    data = text ? JSON.parse(text) : null;
  } catch {
    /* keep text */
  }
  if (!res.ok) {
    const msg =
      typeof data === "object" && data !== null && "msg" in data
        ? String((data as { msg: unknown }).msg)
        : text || res.statusText;
    throw new Error(msg);
  }
  return data;
}

export type AccountBalance = { asset: string; balance: string; availableBalance: string };

export async function futuresAccount(
  apiKey: string,
  apiSecret: string
): Promise<{ assets?: AccountBalance[] }> {
  return signedFetch("GET", "/fapi/v2/account", apiKey, apiSecret) as Promise<{
    assets?: AccountBalance[];
  }>;
}

export type ExchangeSymbol = {
  symbol: string;
  status: string;
  quoteAsset: string;
  contractType?: string;
};

export async function exchangeInfo(): Promise<{ symbols: ExchangeSymbol[] }> {
  const url = `${baseUrl()}/fapi/v1/exchangeInfo`;
  const res = await fetch(url);
  if (!res.ok) throw new Error(await res.text());
  return res.json() as Promise<{ symbols: ExchangeSymbol[] }>;
}

/** USD-M mark price (public). */
export async function fetchMarkPrice(symbol: string): Promise<string> {
  const url = `${baseUrl()}/fapi/v1/premiumIndex?symbol=${encodeURIComponent(symbol)}`;
  const res = await fetch(url);
  const text = await res.text();
  if (!res.ok) throw new Error(text || res.statusText);
  const j = JSON.parse(text) as { markPrice?: string };
  if (!j.markPrice) throw new Error("No mark price");
  return j.markPrice;
}

export async function newOrder(params: {
  apiKey: string;
  apiSecret: string;
  symbol: string;
  side: "BUY" | "SELL";
  positionSide?: "LONG" | "SHORT" | "BOTH";
  type: "LIMIT" | "MARKET";
  timeInForce?: "GTC" | "IOC" | "FOK";
  quantity?: string;
  price?: string;
  reduceOnly?: boolean | string;
}): Promise<unknown> {
  const {
    apiKey,
    apiSecret,
    symbol,
    side,
    positionSide,
    type,
    timeInForce = "GTC",
    quantity,
    price,
    reduceOnly,
  } = params;
  return signedFetch("POST", "/fapi/v1/order", apiKey, apiSecret, {
    symbol,
    side,
    positionSide,
    type,
    timeInForce: type === "LIMIT" ? timeInForce : undefined,
    quantity,
    price,
    reduceOnly: reduceOnly === true ? "true" : reduceOnly === false ? "false" : undefined,
  });
}

export async function cancelAllOpenOrders(
  apiKey: string,
  apiSecret: string,
  symbol: string
): Promise<unknown> {
  return signedFetch("DELETE", "/fapi/v1/allOpenOrders", apiKey, apiSecret, { symbol });
}

export type FuturesOpenOrder = {
  orderId: number;
  symbol: string;
  price: string;
  origQty: string;
  executedQty: string;
  side: "BUY" | "SELL";
  type: string;
  status: string;
};

export async function getOpenOrders(
  apiKey: string,
  apiSecret: string,
  symbol: string
): Promise<FuturesOpenOrder[]> {
  const data = (await signedFetch("GET", "/fapi/v1/openOrders", apiKey, apiSecret, {
    symbol,
  })) as FuturesOpenOrder[];
  return Array.isArray(data) ? data : [];
}

export async function cancelOrderById(
  apiKey: string,
  apiSecret: string,
  symbol: string,
  orderId: number
): Promise<unknown> {
  return signedFetch("DELETE", "/fapi/v1/order", apiKey, apiSecret, { symbol, orderId });
}

export function filterUsdMarginSymbols(symbols: ExchangeSymbol[]): string[] {
  return symbols
    .filter(
      (s) =>
        s.status === "TRADING" &&
        (s.quoteAsset === "USDT" || s.quoteAsset === "USDC") &&
        (s.contractType === "PERPETUAL" || s.contractType === undefined)
    )
    .map((s) => s.symbol)
    .sort();
}
