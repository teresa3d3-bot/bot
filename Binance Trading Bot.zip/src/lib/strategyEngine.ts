/**
 * Grid take-profit (3Commas-style) for Binance USD-M Futures.
 *
 * SHORT (sold at anchor first):
 * - DCA: limit BUYs below anchor, equal quote per level, spacing = stepPct per level (1…20).
 * - Each filled DCA leg adds its base size to ONE limit at the anchor (SELL) — same price,
 *   growing qty (“add to the sale at original entry”).
 * - LONG: mirror — limit SELLs above anchor; consolidated BUY at anchor.
 *
 * After the anchor limit fills (“TP at entry”), reset the ladder for the next wave; volume
 * stats accumulate for reporting.
 */

export type GridSide = "LONG" | "SHORT";

export type LadderLeg = {
  levelIndex: number;
  price: number;
  quoteNotional: number;
  /** Base qty = quote / leg price */
  baseQty: number;
  filled: boolean;
};

export type ConsolidatedOrder = {
  price: number;
  baseQty: number;
  side: "BUY" | "SELL";
};

export type StrategyState = {
  symbol: string;
  gridSide: GridSide;
  anchorPrice: number;
  levelCount: number;
  /** % distance between ladder rungs (your “TP %” between levels). */
  stepPct: number;
  quotePerLevel: number;
  ladder: LadderLeg[];
  consolidated: ConsolidatedOrder | null;
  /** Sum of consolidated base qty that completed a full anchor cycle. */
  accumulatedBaseVolume: number;
  /** Sum of (anchor price × consolidated base) over completed cycles (quote notional). */
  accumulatedQuoteNotional: number;
  cycleCount: number;
};

export function dcaLimitSide(gridSide: GridSide): "BUY" | "SELL" {
  return gridSide === "SHORT" ? "BUY" : "SELL";
}

/** Limit at anchor that stacks size from each DCA fill. */
export function consolidatedLimitSide(gridSide: GridSide): "BUY" | "SELL" {
  return gridSide === "SHORT" ? "SELL" : "BUY";
}

/** DCA legs always reduce an existing position on fill. */
export function dcaIsReduceOnly(_gridSide: GridSide): true {
  return true;
}

export function computeLadderPrices(
  anchor: number,
  gridSide: GridSide,
  levelCount: number,
  stepPct: number
): number[] {
  const mult = stepPct / 100;
  const prices: number[] = [];
  for (let i = 1; i <= levelCount; i += 1) {
    const delta = mult * i;
    if (gridSide === "SHORT") {
      prices.push(anchor * (1 - delta));
    } else {
      prices.push(anchor * (1 + delta));
    }
  }
  return prices;
}

export function buildInitialState(input: {
  symbol: string;
  gridSide: GridSide;
  anchorPrice: number;
  levelCount: number;
  stepPct: number;
  quotePerLevel: number;
}): StrategyState {
  const prices = computeLadderPrices(
    input.anchorPrice,
    input.gridSide,
    input.levelCount,
    input.stepPct
  );
  const ladder: LadderLeg[] = prices.map((price, idx) => ({
    levelIndex: idx + 1,
    price,
    quoteNotional: input.quotePerLevel,
    baseQty: input.quotePerLevel / price,
    filled: false,
  }));
  return {
    symbol: input.symbol,
    gridSide: input.gridSide,
    anchorPrice: input.anchorPrice,
    levelCount: input.levelCount,
    stepPct: input.stepPct,
    quotePerLevel: input.quotePerLevel,
    ladder,
    consolidated: null,
    accumulatedBaseVolume: 0,
    accumulatedQuoteNotional: 0,
    cycleCount: 0,
  };
}

/**
 * After a DCA leg fills: merge its base into the single limit at the anchor (same price, more qty).
 */
export function applyDcaFill(state: StrategyState, levelIndex: number): StrategyState {
  const leg = state.ladder.find((l) => l.levelIndex === levelIndex);
  if (!leg || leg.filled) return state;

  const newLadder = state.ladder.map((l) =>
    l.levelIndex === levelIndex ? { ...l, filled: true } : l
  );
  const filledBase = leg.baseQty;
  const anchorSide = consolidatedLimitSide(state.gridSide);
  const prev = state.consolidated;
  const nextConsolidated: ConsolidatedOrder = {
    price: state.anchorPrice,
    baseQty: (prev?.baseQty ?? 0) + filledBase,
    side: anchorSide,
  };

  return {
    ...state,
    ladder: newLadder,
    consolidated: nextConsolidated,
  };
}

/**
 * Anchor TP line filled: count volume, clear consolidation, reset ladder for the next wave.
 * (On the exchange you’d cancel remaining DCA legs if needed, then re-place this grid.)
 */
export function applyAnchorTpFill(state: StrategyState): StrategyState {
  const c = state.consolidated;
  const vol = c?.baseQty ?? 0;
  const quote = c ? c.price * vol : 0;
  const next = buildInitialState({
    symbol: state.symbol,
    gridSide: state.gridSide,
    anchorPrice: state.anchorPrice,
    levelCount: state.levelCount,
    stepPct: state.stepPct,
    quotePerLevel: state.quotePerLevel,
  });
  return {
    ...next,
    accumulatedBaseVolume: state.accumulatedBaseVolume + vol,
    accumulatedQuoteNotional: state.accumulatedQuoteNotional + quote,
    cycleCount: state.cycleCount + 1,
  };
}

export type PlannedLimitOrder = {
  role: "dca" | "consolidated";
  levelIndex?: number;
  side: "BUY" | "SELL";
  price: number;
  baseQty: number;
  reduceOnly: boolean;
};

/** All limit orders the bot would rest for the current engine state (unfilled DCA + consolidated). */
export function plannedLimitOrders(state: StrategyState): PlannedLimitOrder[] {
  const out: PlannedLimitOrder[] = [];
  const dcaSide = dcaLimitSide(state.gridSide);
  for (const leg of state.ladder) {
    if (leg.filled) continue;
    out.push({
      role: "dca",
      levelIndex: leg.levelIndex,
      side: dcaSide,
      price: leg.price,
      baseQty: leg.baseQty,
      reduceOnly: true,
    });
  }
  if (state.consolidated && state.consolidated.baseQty > 0) {
    out.push({
      role: "consolidated",
      side: state.consolidated.side,
      price: state.consolidated.price,
      baseQty: state.consolidated.baseQty,
      reduceOnly: false,
    });
  }
  return out;
}
